﻿namespace LightstripSyncClient
{
    public class Globals
    {
        public static BluetoothLEConnectionManager BluetoothLEConnectionManager { get; set; }
        public static ColorSync ColorSync { get; set; }

    }
}
